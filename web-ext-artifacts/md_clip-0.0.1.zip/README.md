# md-clip
Clip page to MD extension
